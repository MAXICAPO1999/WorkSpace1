import java.util.concurrent.locks.ReentrantLock;
public class Folk{

  private ReentrantLock lock;
  
  public Folk(){
    this.lock = new ReentrantLock();
  }
  
  public void take () {
    lock.lock();
  }
  
  public void drop() {
    if(!isHeld())
      return;
    lock.unlock();
  }
  
  public boolean isHeld (){
    return lock.isHeldByCurrentThread();
  }
}