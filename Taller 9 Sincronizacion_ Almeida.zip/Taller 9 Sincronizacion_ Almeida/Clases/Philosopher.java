public class Philosopher implements Runnable{

  private String name;
  private Table table;
  private Folk right;
  private Folk left;
  private boolean isLeftHanded;
  
  
  public Philosopher(String name, Table table, Folk left, Folk right, boolean isLeftHanded){
    this.name = name;
    this.table = table;
    this.right = right;
    this.left = left;
    this.isLeftHanded = isLeftHanded;
  }
  
  public void eat() throws InterruptedException{
	  takeForks();
	  long time = table.getTime();
	  System.out.println(name+ " eating during " +time+"ms");
	  spendTime(time);
	  dropForks();
  }
  
  public void think () throws InterruptedException {
    long time = table.getTime();
    System.out.println(name + " thinking during "+ time + "ms");
    spendTime(time);
    dropForks();
  }
  
  public void run() {
    while(true){
      try{
	think();
	eat();
      } catch (Exception e){
	System.out.println(e.getMessage());
      }
    }
  }
  
  public void takeForks (){
    if(isLeftHanded){
      left.take();
      right.take();
    }else{
      right.take();
      left.take();
    }
  }
  
  public void dropForks (){
    if(isLeftHanded){
      left.drop();
      right.drop();
    }else{
      right.drop();
      left.drop();
    }
  }
  
  public void spendTime (long time) throws InterruptedException{
    Thread.sleep(time);
  }
}