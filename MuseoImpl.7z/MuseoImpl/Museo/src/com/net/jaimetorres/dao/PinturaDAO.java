package com.net.jaimetorres.dao;

import java.util.List;
import com.net.jaimetorres.pojos.Pintura;

public interface PinturaDAO {
	public void registrar(Pintura pint) throws Exception;
	public void modificar(Pintura pint) throws Exception;
	public void eliminar(Pintura pint) throws Exception;
	public List<Pintura> listar() throws Exception;
}
