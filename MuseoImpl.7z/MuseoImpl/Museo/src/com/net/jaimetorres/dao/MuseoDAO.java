package com.net.jaimetorres.dao;

import java.util.List;
import com.net.jaimetorres.pojos.Museo;


public interface MuseoDAO {
	public void registrar(Museo mus) throws Exception;
	public void modificar(Museo mus) throws Exception;
	public void eliminar(Museo mus) throws Exception;
	public List<Museo> listar() throws Exception;
}
