package com.net.jaimetorres.dao;

import java.util.List;

import com.net.jaimetorres.pojos.Autor;

public interface AutorDAO {
	
	public void registrar(Autor aut) throws Exception;
	public void modificar(Autor aut) throws Exception;
	public void eliminar(Autor aut) throws Exception;
	public List<Autor> listar() throws Exception;
	
}
