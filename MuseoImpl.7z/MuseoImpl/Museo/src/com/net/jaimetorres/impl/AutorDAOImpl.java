package com.net.jaimetorres.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.net.jaimetorres.bd.Conexion;
import com.net.jaimetorres.dao.AutorDAO;
import com.net.jaimetorres.pojos.Autor;

public class AutorDAOImpl extends Conexion implements AutorDAO{

	@Override
	public void registrar(Autor aut) throws Exception {
		this.crearConexion();
		try(PreparedStatement ps = this.conexion.prepareStatement("INSERT INTO \"Artista\" values(?,?,?);")) {
			
			ps.setInt(1, aut.getId());
			ps.setString(2, aut.getNombre());
			ps.setString(3, aut.getPintura());
			
			ps.executeQuery();
			
		} 
		this.cerrarConexion();
	}

	@Override
	public void modificar(Autor aut) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void eliminar(Autor aut) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Autor> listar() throws Exception {
		// TODO Auto-generated method stub
		this.crearConexion();
		List<Autor> lista = null;
		ResultSet rs = null;
		try(PreparedStatement ps = this.conexion.prepareStatement("select * from \"Artista\";")) {
			lista = new ArrayList<>();
			rs = ps.executeQuery();
			while(rs.next()) {
				Autor aut = new Autor();
				aut.setId(rs.getInt("id"));
				aut.setNombre(rs.getString("nombre"));
				aut.setPintura(rs.getString("pintura"));
				lista.add(aut);
			}
			rs.close();
		} 
		this.cerrarConexion();
		
		return lista;
	}
	
}
