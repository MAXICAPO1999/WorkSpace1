package com.net.jaimetorres.impl;

import java.util.List;
import com.net.jaimetorres.pojos.Pintura;

public class PinturaDAOImpl {
}
