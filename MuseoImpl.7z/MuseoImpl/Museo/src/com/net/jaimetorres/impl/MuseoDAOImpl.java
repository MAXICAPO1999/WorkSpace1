package com.net.jaimetorres.impl;

import java.util.List;
import com.net.jaimetorres.pojos.Museo;


public class MuseoDAOImpl {
}
