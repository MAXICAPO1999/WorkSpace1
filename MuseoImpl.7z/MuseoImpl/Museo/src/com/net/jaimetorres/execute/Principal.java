package com.net.jaimetorres.execute;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.net.jaimetorres.bd.Conexion;
import com.net.jaimetorres.constantes.Constantes;
import com.net.jaimetorres.dao.AutorDAO;
import com.net.jaimetorres.impl.AutorDAOImpl;
import com.net.jaimetorres.pojos.Autor;
import com.net.jaimetorres.pojos.Museo;
import com.net.jaimetorres.pojos.Pintura;

public class Principal {

	public static void main(String[] args) {

		Scanner leer = new Scanner(System.in);
		List<Autor> listAutor = new ArrayList<Autor>();
		List<Museo> listMuseo = new ArrayList<Museo>();
		List<Pintura> listPintura = new ArrayList<Pintura>();
		int opcion = 0;
		while(opcion != 7) {
		System.out.println("----------Programa Museo----------");
		System.out.println("Por favor digite el numero de la opcion:");
		System.out.println("1. Crear artista.");
		System.out.println("2. Crear museo.");
		System.out.println("3. Crear pintura.");
		System.out.println("4. Listar artistas.");
		System.out.println("5. Listar museos.");
		System.out.println("6. Listar pinturas.");
		System.out.println("7. Salir");
		opcion = leer.nextInt();

			switch (opcion) {
			case 1:
				
				System.out.println("Digite el codigo del artista: ");
				int cod = leer.nextInt();
				System.out.println("Digite el nombre del artista: ");
				String nombre = leer.next();
				System.out.println("Digite la pintura del artista: ");
				String pintura = leer.next();
				
				Autor autor = new Autor(cod,nombre,pintura);
				listAutor.add(autor);
				
				try {
					AutorDAO aut = new AutorDAOImpl();
					aut.registrar(autor);
				} catch (Exception e) {
					// TODO: handle exception
				}
				break;
			case 2:

				break;

			case 3:

				break;

			case 4:
				AutorDAO aut = new AutorDAOImpl();
				try {
					for (Autor autorList: aut.listar()) {
						System.out.println(autorList.getId()+"-"+autorList.getNombre()+"-"+autorList.getPintura());
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 5:

				break;

			case 6:

				break;

			case 7:
				System.out.println("Gracias por usar el software");
				System.exit(0);
				break;

			default:
				System.out.println("Esa opcion no es valida.");
				break;
			}
		}



	}

}
