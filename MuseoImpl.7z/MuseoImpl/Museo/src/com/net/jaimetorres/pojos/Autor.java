package com.net.jaimetorres.pojos;

public class Autor {

	int id;
	String nombre;
	String pintura;
	
	public Autor(int id, String nombre, String pintura) {
		this.id = id;
		this.nombre = nombre;
		this.pintura = pintura;
	}

	public Autor() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPintura() {
		return pintura;
	}

	public void setPintura(String pintura) {
		this.pintura = pintura;
	}
	
}
