package com.net.jaimetorres.pojos;

public class Pintura {
	
	int id;
	String nombre;
	String museo;
	String artista;
	public Pintura(int id, String nombre, String museo, String artista) {
		this.id = id;
		this.nombre = nombre;
		this.museo = museo;
		this.artista = artista;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getMuseo() {
		return museo;
	}
	public void setMuseo(String museo) {
		this.museo = museo;
	}
	public String getArtista() {
		return artista;
	}
	public void setArtista(String artista) {
		this.artista = artista;
	}
	
}

