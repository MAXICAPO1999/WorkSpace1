package com.net.jaimetorres.constantes;

public enum Constantes {
	UNO(1),
	DOS(2),
	TRES(3),
	CUATRO(4),
	CINCO(5),
	SEIS(6);
	
	private int code;
	private Constantes(int i) {
		code = i;
	}
	
	public int code() {
		return code;
	}
	
}
