package com.net.jaimetorres.bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
	
	public Connection conexion;
	static final String URL = "jdbc:postgresql://localhost:5432/postgres";
	static final String USSER = "postgres";
	static final String PASSWORD = "Clave123";
	
	public Connection crearConexion() {
		try {
			Class.forName("org.postgresql.Driver");
			try {
				conexion = DriverManager.getConnection(URL, USSER, PASSWORD);
				if(conexion != null) {
					System.out.println("Conexion Establecida...");
					return conexion;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void cerrarConexion() {
		try {
			if(conexion != null && !conexion.isClosed()) {
				conexion.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
